<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'NoFollow';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Automatisches Hinzuf&uuml;gen des NoFollow Attributs zu den externen Links im Forum';
?>