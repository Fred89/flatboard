<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * nofollow
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2016-2017
 * @license		http://opensource.org/licenses/MIT
 * @package		FlatBoard
 * @version		2.0
 * @update		2019-02-15
 */	
 
/**
 * On pré-installe les paramètres par défauts.
**/
function nofollow_install()
{
	$plugin = 'nofollow';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state']   = false;    
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function nofollow_config()
{    
	   global $lang, $token; 
       $plugin = 'nofollow';
       $out ='';
     
       if(!empty($_POST) && CSRF::check($token) )
       {
               $data[$plugin.'state'] = Util::isPOST('state') ? $_POST['state'] : '';             
               flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
       }
        else
       {
               if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
               $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
               HTMLForm::checkBox('state', isset($data)? $data[$plugin.'state'] : '').          
               HTMLForm::simple_submit());
       }
       return $out;
}
/**
 * On charge la minification avant
**/
function nofollow_footerJS()
{
  global $out;
  $plugin = 'nofollow';
  # Lecture des données
  $PluginActivate = FlatDB::readEntry('plugin',$plugin)[$plugin.'state'];
  if ($PluginActivate) 
  	return '<script>$(document).ready(function($){ $(\'a[href^="http"]\').attr(\'rel\',\'nofollow\'); });</script>'.PHP_EOL;	      
}