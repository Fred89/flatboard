<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * Plugin Page
 *
 * @version	1.0
 * @update  2020-04-01
 * @author	Simon Ledoux
**/

/**
 * On pré-installe les paramètres par défauts.
**/
function faker_install()
{
	global $lang;
	$plugin = 'faker';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;
	# Action requise par l'utilisateur
    $data[$plugin.'state'] = false;
    #$data['cantDisable'] = true;
    flatDB::saveEntry('plugin', $plugin, $data);
}

function faker_config()
{
	global $lang, $token;
	$plugin = 'faker';
	$out = '';

	$forums = flatDB::listEntry('forum');
	$forumsSelect = array();
	foreach($forums as $forum){
		$forumName = flatDB::readEntry('forum', $forum)['name'];
		$forumsSelect[$forum] = $forumName;
	}
	
	if(!empty($_POST) && CSRF::check($token) )
       {       
			faker_generate($_POST['forum'], $_POST[$plugin.'number_of_topics'], $_POST[$plugin.'number_of_replys']);
			$out .= Plugin::redirectMsg($lang[$plugin.'generated'],'view.php' . DS . 'forum' . DS . $_POST['forum'], '<b>' . $forumsSelect[$_POST['forum']] . '</b>');
       }
        else
       {
			$out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
			HTMLForm::select('forum', $forumsSelect).
			HTMLForm::text($plugin.'number_of_topics', 20, 'number').
			HTMLForm::text($plugin.'number_of_replys', 10, 'number').
			HTMLForm::simple_submit($plugin.'generate'));
       }

	return $out;
}

function faker_generate($forum, $number_of_topics = 20, $number_of_replys = 10){
	$forumEntry = flatDB::readEntry('forum', $forum);
	for($i = 0; $i < $number_of_topics; $i++){
		$topicEntry = array();
		$topicEntry['ip'] = faker_generate_ipv4();
		$topicEntry['role'] = '';
		$topicEntry['tag'] = '';
		$topicEntry['title'] = faker_generate_title();
		$topicEntry['mail'] = faker_generate_email();
		$topicEntry['content'] = faker_generate_content('topic');
		$topicEntry['view'] = 0;
		$topicEntry['forum'] = $forum;
		$topicEntry['reply'] = array();
		$topicEntry['locked'] = false;
		$topic = flatDB::newEntry();
		$topicEntry['trip'] = faker_generate_trip($topic);
		flatDB::saveEntry('topic', $topic, $topicEntry);
		$forumEntry['topic'][$topic] = $topic;
		flatDB::saveEntry('forum', $topicEntry['forum'], $forumEntry);
		for($i2 = 0; $i2 < $number_of_replys; $i2++){
			faker_generate_reply($topic);
		}
	}
}

function faker_generate_reply($topic){
	$topicEntry = flatDB::readEntry('topic', $topic);
	$replyEntry['ip'] = faker_generate_ipv4();
	$replyEntry['role'] = '';	
	$replyEntry['content'] = faker_generate_content('reply');
	$replyEntry['topic'] = $topic;
	$reply = flatDB::newEntry();
	$replyEntry['trip'] = faker_generate_trip($topic);
	$replyEntry['mail'] = faker_generate_email();
	flatDB::saveEntry('reply', $reply, $replyEntry);

	$topicEntry['reply'][$reply] = $reply;
	flatDB::saveEntry('topic', $replyEntry['topic'], $topicEntry);
}

function faker_generate_ipv4(){
	return long2ip(rand(0, "4294967295"));
}

function faker_generate_title(){
	require_once(PLUGIN_DIR . 'faker' . DS . 'LoremIpsum.php');
	$lipsum = new joshtronic\LoremIpsum();
	return $lipsum->words(10);
}

function faker_generate_email(){
	$extensions = ['fr', 'com'];
	return faker_generate_string(rand(5,15)) . '@' . faker_generate_string(rand(5,15)) . '.' . $extensions[rand(0,1)];
}

function faker_generate_string($length){ 
    $characters = "abcdefghijklmnopqrstuvwxyz";
    $charsLength = strlen($characters) -1;
    $string = "";
    for($i=0; $i<$length; $i++){
        $randNum = mt_rand(0, $charsLength);
        $string .= $characters[$randNum];
    }
    return $string;
}

function faker_generate_content($is = 'topic'){
	require_once(PLUGIN_DIR . 'faker' . DS . 'LoremIpsum.php');
	$lipsum = new joshtronic\LoremIpsum();
	if($is == 'topic'){
		return $lipsum->paragraphs(2);
	}else{
		return $lipsum->paragraph();
	}
}

function faker_generate_trip($topic){
	require_once LIB_DIR . DS . 'Parser.lib.php';
	return HTMLForm::trip(Parser::translitIt(faker_generate_string(rand(5,8)) . '@' . faker_generate_string(rand(5,10))), $topic);
}