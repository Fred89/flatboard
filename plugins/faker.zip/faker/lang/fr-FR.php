<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Faker';
$lang[$plugin.'version']         = '1.0';
$lang[$plugin.'update']          = '2020-04-01';
$lang[$plugin.'author']          = 'Simon Ledoux';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'simon@simon511000.fr';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Générateur aléatoire de discussions et de réponses Lorem Ipsum.';
$lang[$plugin.'number_of_topics'] = 'Nombre de discussions à génerer';
$lang[$plugin.'number_of_replys'] = 'Nombre de réponses par discussion';
$lang[$plugin.'generate'] = 'Générer';
$lang[$plugin.'generated'] = 'Généré!';
?>