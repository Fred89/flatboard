<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Faker';
$lang[$plugin.'version']         = '1.0';
$lang[$plugin.'update']          = '2020-04-01';
$lang[$plugin.'author']          = 'Simon Ledoux';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'simon@simon511000.fr';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Random generator of discussions and responses Lorem Ipsum.';
$lang[$plugin.'number_of_topics'] = 'Number of topics to generate';
$lang[$plugin.'number_of_replys'] = 'Number of responses per topic';
$lang[$plugin.'generate'] = 'Generate';
$lang[$plugin.'generated'] = 'Generated!';
?>