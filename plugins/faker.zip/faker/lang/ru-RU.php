<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Faker';
$lang[$plugin.'version']         = '1.0';
$lang[$plugin.'update']          = '2020-04-01';
$lang[$plugin.'author']          = 'Simon Ledoux';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'simon@simon511000.fr';
/************* Langue ru ***************/
$lang[$plugin.'description']     = 'Генератор рандомно созданный тем и ответов на форуме на основе текста Lorem Ipsum.';
$lang[$plugin.'number_of_topics'] = 'Количество тем, которое нужно сгенерировать';
$lang[$plugin.'number_of_replys'] = 'Количество ответов в теме';
$lang[$plugin.'generate'] = 'Сгенерировать';
$lang[$plugin.'generated'] = 'Сгенерировано!';
?>