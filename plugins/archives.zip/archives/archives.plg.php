<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * archives
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2015-2021
 * @license		http://opensource.org/licenses/MIT
 * @package		FlatBoard
 * @version		2.6
 * @update		2021-06-10
 */	
 
/**
 * On pré-installe les paramètres par défauts.
**/
function archives_install()
{
	global $lang;
	$plugin = 'archives';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state']   	  	= false;
	$data['menu']   			  	= 'Archives';  
	$data[$plugin.'display_menu'] 	= true;  
	$data['archives_months_format']	= $lang['data_months_format'];
	$data['archives_dates_format']	= $lang['data_dates_format'];     
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function archives_config()
{    
	   global $lang, $token; 
       $plugin = 'archives';
       $out ='';
     
       if(!empty($_POST) && CSRF::check($token) )
       {
               $data[$plugin.'state']= Util::isPOST('state') ? $_POST['state'] : ''; 
               $data['menu'] 		 = HTMLForm::clean($_POST['menu']); 
               $data[$plugin.'display_menu'] = isset($_POST['display_menu'])? $_POST['display_menu'] : '';
               $data['archives_months_format']	 = HTMLForm::clean($_POST['archives_months_format']);  
               $data['archives_dates_format']	 = HTMLForm::clean($_POST['archives_dates_format']);         
               flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
       }
        else
       {
               if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
               $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin, '
				<div class="row">
				    <div class="col">'.
				    HTMLForm::checkBox('state', $data[$plugin.'state']). '
				    </div>
				    <div class="col">'.
				    HTMLForm::checkBox('display_menu', isset($data)? $data[$plugin.'display_menu'] : ''). '
				    </div>
				</div>
				<div class="row">
				    <div class="col">'.
				    HTMLForm::text('menu', isset($data)? $data['menu'] : ''). '
				    </div>
				    <div class="col">'.
				    HTMLForm::text('archives_months_format', isset($data)? $data['archives_months_format'] : '', 'text', '', 'date_format_placeholder', 'date_format_desc'). '
				    </div>
				    <div class="col">'.
				    HTMLForm::text('archives_dates_format', isset($data)? $data['archives_dates_format'] : '', 'text', '', 'date_format_placeholder', 'date_format_desc'). '
				    </div>
				</div>' .        
               HTMLForm::simple_submit());
       }
       return $out;
} 
/**
 * Menu
**/
function archives_menu()
{
  $plugin = 'archives';
  global $lang, $cur;
  $out ='';
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  if ($data[$plugin.'state'] && $data[$plugin.'display_menu']) 
    $out .= '<li class="list-inline-item"><a class="nav-link' .($cur==$plugin ? ' active' : ''). '" href="view.php' . DS . 'plugin' . DS .$plugin. '"><i class="fa fa-archive" aria-hidden="true"></i> ' .$data['menu']. '</a></li>';
  
  return $out;  
}
/**
 * Page du plugin
**/
function archives_view()
{
  global $lang;	
  $plugin = 'archives';
  $out ='';	  	  
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  
  $year = (isset($_GET['year']) ? $_GET['year'] : null);
  
  # Return year archives   
  if ($data[$plugin.'state'] && $year) 
  { 
	  	$archivedPosts = array();
		$topics = flatDB::listEntry('topic');
		sort($topics);
		foreach($topics as $topic)
		{
		    if($year === substr($topic, 0, 4))
		    {
		        $month = substr($topic, 5, 2);
		        $archivedPosts[$month][] = $topic;
		    } 
		}
		if(!$archivedPosts)
			$out .= Plugin::redirectMsg(Util::lang('no_archive %s', $year), 'view.php' . DS . 'plugin' . DS . $plugin, $lang['archives'], 'alert alert-danger');
		else        
			$out .= '<h4><a href="view.php' . DS . 'plugin' . DS . $plugin. '" data-toggle="tooltip" data-placement="top" title="' .$lang['back']. '"><i class="fa fa-arrow-circle-o-left"></i></a> ' .$year. '</h4>
		
		<div class="row lh-100 d-flex p-3 my-3 bg-white rounded box-shadow">';	
		ksort($archivedPosts);	    
		foreach($archivedPosts as $monthPosts)
		{
		    $out .= '<div class="col-4">
			    <h6>' .Util::toDate($monthPosts[0], $data['archives_months_format']). '</h6>
			    <ul class="list-unstyled">';
			    foreach($monthPosts as $topic)
			    {
			        $topicEntry = flatDB::readEntry('topic', $topic);
			        $out .= '<li><small>' .Util::toDate($topic, $data['archives_dates_format']). ' - ' .entryLink::manageTopic($topic). '<a href="view.php/topic/' .$topic. '">' .Parser::title($topicEntry['title']). '</a></small></li>';
			    }
			    $out .= '</ul>
		    	</div>';
		}
		$out .= '</div>';		    	    
  } else {
		# List years
		$archives = (isset($archives) ? $archives : null);
		$archives = array();
		$topics = flatDB::listEntry('topic');
		sort($topics);
		foreach($topics as $topic)
		{
			$year = substr($topic, 0, 4);
			if(isset($archives[$year]))
				$archives[$year]++;
			else
				$archives[$year] = 1;
		}
		
		$out .= '<div class="row">';
		if($archives){
			#natcasesort($archives);					
			foreach($archives as $years => $count)
				$out .= '<div class="col">
							<a href="view.php' . DS . 'plugin' . DS . $plugin . DS . 'year' . DS . $years. '" class="btn btn-primary">
								' .$years. ' <small class="badge badge-light">' .intval($count). '</small>
							</a>
						</div>';
		} else {
			$out .= '<div class="col">' .$lang['none']. '</div>';
		}
		$out .= '</div>';	   	
  } 
  
  return $out;  
}
?>