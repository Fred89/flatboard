<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Archiv';
$lang[$plugin.'version']        = '2.6';
$lang[$plugin.'update']         = '2021-06-10';
$lang[$plugin.'author']         = 'Frédéric K.';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']    = 'Erstellen Sie eine Archivseite nach Jahren zu allen Themen, sortiert nach Monaten.';

$lang['menu']                   = 'Men&uuml;';
$lang[$plugin.'display_menu']   = 'Im Men&uuml; anzeigen';
$lang['archives']               = 'Archive';
$lang['back']                   = 'Zur&uuml;ck';
$lang['no_archive']             = 'Kein Archiv in';
$lang['archives_months_format'] = 'Monatsformat';
$lang['archives_dates_format']  = 'Datumsformat';
$lang['data_months_format'] 	= 'F';
$lang['data_dates_format'] 		= 'jS';
?>