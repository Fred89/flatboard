<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Archives';
$lang[$plugin.'version']        = '2.6';
$lang[$plugin.'update']         = '2021-06-10';
$lang[$plugin.'author']         = 'Frédéric K.';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']    = 'Génère une page d’archives de tous les sujets du forum par ans, trié par mois.';

$lang['menu']    				= 'Menu';
$lang[$plugin.'display_menu']   = 'Afficher dans le menu';
$lang['archives'] 			    = 'Archives';
$lang['back']					= 'Retour';
$lang['no_archive']				= 'Aucune archive sur l’année';
$lang['archives_months_format'] = 'Format des mois';
$lang['archives_dates_format']  = 'Format de la date';
$lang['data_months_format'] 	= '%B';
$lang['data_dates_format'] 		= '%a %e';
?>