<?php /* Translation: https://r-e-d.red (Last update 2019.04.01)*/
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Archives';
$lang[$plugin.'version']        = '2.6';
$lang[$plugin.'update']         = '2021-06-10';
$lang[$plugin.'author']         = 'Frédéric K.';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'stradfred@gmail.com';
/************* Langue ru ***************/
$lang[$plugin.'description']    = 'Создаёт страницу архивных записей, рассортированных по годам со всеми темами форума, отсортиронными по месяцам.';

$lang['menu']    				= 'Меню';
$lang[$plugin.'display_menu']   = 'Отображать в меню';
$lang['archives'] 			    = 'Архивы';
$lang['back']					= 'Назад';
$lang['no_archive']				= 'Нет архивных записей в';
$lang['archives_months_format'] = 'Формат месяца';
$lang['archives_dates_format']  = 'Формат даты';
$lang['data_months_format'] 	= 'F';
$lang['data_dates_format'] 		= 'jS';
?>