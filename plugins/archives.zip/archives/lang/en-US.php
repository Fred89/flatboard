<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Archives';
$lang[$plugin.'version']        = '2.6';
$lang[$plugin.'update']         = '2021-06-10';
$lang[$plugin.'author']         = 'Frédéric K.';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'stradfred@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Generate a archives page by years on all topics, sort by months.';

$lang['menu']    				= 'Menu';
$lang[$plugin.'display_menu']   = 'Display in menu';
$lang['archives'] 			    = 'Archives';
$lang['back']					= 'Back';
$lang['no_archive']				= 'No archive in';
$lang['archives_months_format'] = 'Month format';
$lang['archives_dates_format']  = 'Date format';
$lang['data_months_format'] 	= 'F';
$lang['data_dates_format'] 		= 'jS';
?>