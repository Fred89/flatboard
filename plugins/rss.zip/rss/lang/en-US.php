<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'RSS Feed';
$lang[$plugin.'version']     	 = '2.0';
$lang[$plugin.'update']      	 = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Generate a rss feed on external site.';

$lang['menu']    				= 'Menu';
$lang[$plugin.'display_menu']   = 'Display in menu';
$lang['rss'] 			    	= 'RSS Feed';
$lang['back']					= 'Back';
$lang['no_archive']				= 'No archive in';
$lang['rss_months_format'] 		= 'Month format';
$lang['rss_dates_format'] 	    = 'Date format';
$lang['rss_site']  				= 'Site Title';
$lang['rss_url']  				= 'Url rss site';
$lang['rss_url_desc']  		    = 'Only RSS feeds!';
$lang['nb_art']  				= 'Number of article limite';
?>