<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'RSS Feed';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Erzeugen Sie einen RSS-Feed von einer externen Website..';

$lang['menu']                    = 'Men&uuml;';
$lang[$plugin.'display_menu']    = 'Im Men&uuml; anzeigen';
$lang['rss']                     = 'RSS Feed';
$lang['back']                    = 'Zur&uuml;ck';
$lang['no_archive']              = 'Kein Archiv in';
$lang['rss_months_format']       = 'Monatsformat';
$lang['rss_dates_format']        = 'Datumsformat';
$lang['rss_site']                = 'Seitentiel';
$lang['rss_url']                 = 'Seiten-URL des RSS-Feeds';
$lang['rss_url_desc']            = 'Nur RSS-Feeds!';
$lang['nb_art']                  = 'Limitierung der Anzahl der Artikel';
?>