<?php
/* Translation: https://r-e-d.red (Last update 2019.04.01)*/
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'RSS Feed';
$lang[$plugin.'version']     	 = '2.0';
$lang[$plugin.'update']      	 = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue ru ***************/
$lang[$plugin.'description']     = 'Плагин создаёт RSS-канал для внешних сайтов.';

$lang['menu']    				= 'Меню';
$lang[$plugin.'display_menu']   = 'Отображать в меню';
$lang['rss'] 			    	= 'RSS-лента';
$lang['back']					= 'Назад';
$lang['no_archive']				= 'Нет архива в';
$lang['rss_months_format'] 		= 'Формат месяца';
$lang['rss_dates_format'] 	    = 'Формат даты';
$lang['rss_site']  				= 'Название сайта';
$lang['rss_url']  				= 'Url адрес RSS-ленты сайта';
$lang['rss_url_desc']  		    = 'Только RSS-ленты!';
$lang['nb_art']  				= 'Ограничение на количество элементов';
?>