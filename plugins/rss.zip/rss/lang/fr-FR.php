<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'RSS Feed';
$lang[$plugin.'version']     	 = '2.0';
$lang[$plugin.'update']      	 = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Génère le flux rss d’une page externe.';

$lang['menu']    				= 'Menu';
$lang[$plugin.'display_menu']   = 'Afficher dans le menu';
$lang['archives'] 			    = 'Archives';
$lang['back']					= 'Retour';
$lang['no_archive']				= 'Aucune archive sur l’année';
$lang['rss_months_format']	    = 'Format des mois';
$lang['rss_dates_format']  		= 'Format de la date';
$lang['rss_site']  				= 'Nom du site';
$lang['rss_url']  				= 'Lien du flux du site';
$lang['rss_url_desc']  		    = 'Flux RSS uniquement !';
$lang['nb_art']  				= 'Nombre d’article à limiter';
?>