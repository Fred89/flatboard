<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * rss
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2015-2019
 * @license		http://opensource.org/licenses/MIT
 * @package		FlatBoard
 * @version		2.0
 * @update		2019-02-15
 */	
 
/**
 * On pré-installe les paramètres par défauts.
**/
function rss_install()
{
	$plugin = 'rss';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state']   	  	= false;
	$data['menu']   			  	= 'Rss Feed';  
	$data[$plugin.'display_menu'] 	= false;  
	$data['rss_site']				= 'PluXml';
	$data['rss_url']				= 'http://www.pluxml.org/feed/rss';
	$data['nb_art']					= 8;      
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function rss_config()
{    
	   global $lang, $token; 
       $plugin = 'rss';
       $out ='';
     
       if(!empty($_POST) && CSRF::check($token) )
       {
               $data[$plugin.'state']		 = Util::isPOST('state') ? $_POST['state'] : ''; 
               $data['menu'] 				 = HTMLForm::clean($_POST['menu']); 
               $data[$plugin.'display_menu'] = isset($_POST['display_menu'])? $_POST['display_menu'] : '';
               $data['rss_site']	 	 	 = HTMLForm::clean($_POST['rss_site']);  
               $data['rss_url']	 			 = HTMLForm::clean($_POST['rss_url']);  
               $data['nb_art']	 			 = HTMLForm::clean($_POST['nb_art']);          
               flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
       }
        else
       {
               if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
               $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
               HTMLForm::checkBox('state', isset($data)? $data[$plugin.'state'] : ''). '
 				<div class="row">
				    <div class="col">'.
				    	HTMLForm::checkBox($plugin.'display_menu', isset($data)? $data[$plugin.'display_menu'] : ''). '
				    </div>
				    <div class="col">'.
				   		HTMLForm::text('menu', isset($data)? $data['menu'] : ''). '
				    </div>				    
				</div>
 				<div class="row">
				    <div class="col">'.
				    	HTMLForm::text('rss_site', isset($data)? $data['rss_site'] : ''). '
				    </div>
				    <div class="col">'.
				   		HTMLForm::text('rss_url', isset($data)? $data['rss_url'] : '', 'url', '', '', 'rss_url_desc'). '
				    </div>				    
				</div>'.              
               HTMLForm::text('nb_art', isset($data)? $data['nb_art'] : '', 'number', 'col-2').       
               HTMLForm::simple_submit());
       }
       return $out;
} 
/** 
 * Ajoute la css en haut de page du thème (header.html)
 */
function rss_head()
{
  	$plugin = 'rss';
  	# Lecture des données
  	$data = flatDB::readEntry('plugin', $plugin);
  	if ($data[$plugin.'state'])	return '<style type="text/css">.rss_post{margin: 20px 0 40px 0}.rss_post h4 a{font-size:25px;color:#e67e22}.rss_post h4 a:hover{color:#e74c3c}hr.h_rss,hr.h_rss:before{height:30px;border-style:solid;border-color:#8c8b8b;border-radius:20px}hr.h_rss{border-width:1px 0 0}hr.h_rss:before{display:block;content:"";margin-top:-31px;border-width:0 0 1px}</style>';
}
/**
 * Menu
**/
function rss_menu()
{
  $plugin = 'rss';
  global $lang, $cur;
  $out ='';
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  if ($data[$plugin.'state'] && $data[$plugin.'display_menu']) 
    $out .= '<li class="list-inline-item"><a class="nav-link' .($cur==$plugin ? ' active' : ''). '" href="view.php' . DS . 'plugin' . DS .$plugin. '"><i class="fa fa-rss" aria-hidden="true"></i> ' .$data['menu']. '</a></li>';
  
  return $out;  
}
/**
 * Pagedu plugin
**/
function rss_view()
{
  global $lang;	
  $plugin = 'rss';
  $out ='';	  	  
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  require_once(dirname(__FILE__). DS . 'rss.class.php');  
  
  # Return rss site feed  
  if ($data[$plugin.'state']) 
  { 
	$rss = new RSSParser();	
	$rss->load($data['rss_url']);
	
	$out .='<h2>' .$data['rss_site']. '</h2>';

    $nb = $data['nb_art'];
	$total = Paginate::countPage($rss->getItems(), $nb);
	$p = Paginate::pid($total);	
	foreach(Paginate::viewPage($rss->getItems(), $p, $nb) as $item) 
	{
	 
	    $out .='<div class="rss_post"><h4><a href="'.$item->getLink().'">'.$item->getTitle().'</a></h4><p>'.$item->getDescription().'</p></div><hr class="h_rss">';
	}
	$out .= Paginate::pageLink($p, $total, 'view.php' . DS . 'plugin' . DS . $plugin);	  	   
     
  }
  
  return $out;  
}
?>