<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Scroll to top';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Allow your website visitors to easily scroll back to the top of the page.';
$lang['top']                 	 = 'Top';
$lang['design']                  = 'Select arrow style';
$lang['up-arrow']                = 'Type 1';
$lang['up-arrow2']               = 'Type 2';
$lang['up-arrow3']               = 'Type 3';
$lang['up-arrow4']               = 'Type 4';
$lang['up-arrow5']               = 'Type 5';
$lang['up-arrow6']               = 'Type 6';
$lang['up-arrow7']               = 'Type 7';
$lang['up-arrow8']               = 'Type 8';
$lang['up-arrow9']               = 'Type 9';
$lang['up-arrow10']              = 'Type 10';
?>