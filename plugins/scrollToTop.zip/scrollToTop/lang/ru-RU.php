<?php
/* Translation: https://r-e-d.red (Last update 2019.04.01)*/
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Scroll to top';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue ru ***************/
$lang[$plugin.'description']     = 'Позволяет посетителям вашего сайта легко обратно в начало страницы.';
$lang['top']                 	 = 'Наверх';
$lang['design']                  = 'Выберите тип стрелки';
$lang['up-arrow']                = 'Тип 1';
$lang['up-arrow2']               = 'Тип 2';
$lang['up-arrow3']               = 'Тип 3';
$lang['up-arrow4']               = 'Тип 4';
$lang['up-arrow5']               = 'Тип 5';
$lang['up-arrow6']               = 'Тип 6';
$lang['up-arrow7']               = 'Тип 7';
$lang['up-arrow8']               = 'Тип 8';
$lang['up-arrow9']               = 'Тип 9';
$lang['up-arrow10']              = 'Тип 10';
?>