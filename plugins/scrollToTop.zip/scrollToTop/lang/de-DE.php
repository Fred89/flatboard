<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Nach oben scrollen';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Gestatte deinen Forum-Besuchern, im Forum nach oben zu scrollen.';
$lang['top']                     = 'Top';
$lang['design']                  = 'Pfeilart ausw&auml;hlen';
$lang['up-arrow']                = 'Art 1';
$lang['up-arrow2']               = 'Art 2';
$lang['up-arrow3']               = 'Art 3';
$lang['up-arrow4']               = 'Art 4';
$lang['up-arrow5']               = 'Art 5';
$lang['up-arrow6']               = 'Art 6';
$lang['up-arrow7']               = 'Art 7';
$lang['up-arrow8']               = 'Art 8';
$lang['up-arrow9']               = 'Art 9';
$lang['up-arrow10']              = 'Art 10';
?>