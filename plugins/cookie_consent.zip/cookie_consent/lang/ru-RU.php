<?php
/* Translation: https://r-e-d.red (Last update 2019.04.01)*/
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Cookie Consent';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'https://cookieconsent.insites.com';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue ru ***************/
$lang[$plugin.'description']     = 'Популярное решение для соблюдения законодательства EC, а также детектором AdBlock и детальной настройкой плагина.';

$lang['default_cookie_msg'] = 'Этот сайт использует cookies, чтобы обеспечить вам максимальный функционал на сайте.';
$lang['palette']  	   		= 'Выберите цвет темы';

$lang['theme']  	   		= 'Общий вид';  
$lang['block']  	   		= 'Прямоугольный'; 
$lang['classic']  	   		= 'Классический'; 
$lang['edgeless']  	   		= 'Безрамочный'; 
 
$lang['position']  	   		= 'Позиция баннера'; 
$lang['banner_bottom'] 		= 'Баннер внизу';  
$lang['banner_top']    		= 'Баннер вверху';
$lang['floating_left'] 		= 'Слева в углу';
$lang['floating_right']		= 'Справа в углу';

$lang['message']   	   		= 'Сообщение';
$lang['dismiss']  	   		= 'Текст кнопки';
$lang['link']  	  	   		= 'Текст ссылки на документ/закон';  
$lang['href']  	       		= 'Ссылка на на документ/закон'; 

$lang['or']					= 'или'; 

$lang['custom_palette']		= 'Настроить цвета'; 
$lang['custom_banner']		= 'Цвет баннера';  
$lang['custom_banner_text'] = 'Цвет текста'; 
$lang['custom_button']    	= 'Цвет кнопки';
$lang['custom_button_text'] = 'Цвет текста на кнопке';

?>