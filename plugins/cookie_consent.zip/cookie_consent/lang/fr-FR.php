<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Cookie Consent';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'https://cookieconsent.insites.com';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'La solution la plus populaire pour le droit des Cookies en Europe.';

$lang['default_cookie_msg'] = 'En poursuivant votre navigation sur ce site, vous acceptez que des cookies soient utilisés afind’améliorer votre expérience d’utilisateur et de vous offrir des contenus personnalisés.';
$lang['palette']  	   		= 'Choisissez votre palette de couleur';

$lang['theme']  	   		= 'Choisissez un thème';  
$lang['block']  	   		= 'Bloc'; 
$lang['classic']  	   		= 'Classique'; 
$lang['edgeless']  	   		= 'Edgeless'; 
 
$lang['position']  	   		= 'Position'; 
$lang['banner_bottom'] 		= 'Pied de page';  
$lang['banner_top']    		= 'Haut de page';
$lang['floating_left'] 		= 'Boite flottante à gauche';
$lang['floating_right']		= 'Boite flottante à droite';

$lang['message']   	   		= 'Message';
$lang['dismiss']  	   		= 'Texte du bouton qui permet de fermer l’avertissement';
$lang['link']  	  	   		= 'Texte du lien de politique sur les cookies';  
$lang['href']  	       		= 'Lien vers l’affichage de politique sur les cookies'; 

$lang['or']					= 'ou'; 

$lang['custom_palette']		= 'Personnaliser les couleurs'; 
$lang['custom_banner']		= 'Couleur de la bannière';  
$lang['custom_banner_text'] = 'Texte de la bannière'; 
$lang['custom_button']    	= 'Couleur du bouton';
$lang['custom_button_text'] = 'Texte du bouton';

?>