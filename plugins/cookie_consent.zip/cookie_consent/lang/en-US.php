<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Cookie Consent';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'https://cookieconsent.insites.com';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'The most popular solution to the EU Cookie Law, as well as a detector with AdBlock script customization.';

$lang['default_cookie_msg'] = 'This website uses cookies to ensure you get the best experience on our website.';
$lang['palette']  	   		= 'Choose a colour theme';

$lang['theme']  	   		= 'Layout';  
$lang['block']  	   		= 'Block'; 
$lang['classic']  	   		= 'Classic'; 
$lang['edgeless']  	   		= 'Edgeless'; 
 
$lang['position']  	   		= 'Position'; 
$lang['banner_bottom'] 		= 'Banner bottom';  
$lang['banner_top']    		= 'Banner top';
$lang['floating_left'] 		= 'Floating left';
$lang['floating_right']		= 'Floating right';

$lang['message']   	   		= 'Message';
$lang['dismiss']  	   		= 'Dismiss button text';
$lang['link']  	  	   		= 'Policy link text';  
$lang['href']  	       		= 'Link to your own policy'; 

$lang['or']					= 'or'; 

$lang['custom_palette']		= 'Customize colors'; 
$lang['custom_banner']		= 'Banner';  
$lang['custom_banner_text'] = 'Banner text'; 
$lang['custom_button']    	= 'Button';
$lang['custom_button_text'] = 'Button text';

?>