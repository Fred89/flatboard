<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Cookie Consent';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'https://cookieconsent.insites.com';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Die beliebteste L&ouml;sung des EU-Cookie Gesetz sowie ein Detektor mit AdBlock-Skriptanpassung.';

$lang['default_cookie_msg'] 	 = 'Diese Website verwendet Cookies, um sicherzustellen, dass du das beste Surferlebnis auf meiner Website erzielst.';
$lang['palette']                 = 'W&auml;hle ein Farbschema aus';

$lang['theme']                   = 'Layout';
$lang['block']                   = 'Block';
$lang['classic']                 = 'Klassisch';
$lang['edgeless']                = 'Kantenlos';

$lang['position']                = 'Position';
$lang['banner_bottom']           = 'Banner unten';
$lang['banner_top']              = 'Banner oben';
$lang['floating_left']           = 'Schwebend links';
$lang['floating_right']          = 'Schwebend rechts';

$lang['message']                 = 'Nachricht';
$lang['dismiss']                 = 'Text der Schaltfl&auml;che verwerfen';
$lang['link']                    = 'Text des Richtlinien-Links';
$lang['href']                    = 'Link zu deiner eigenen Richtlinie';

$lang['or']                      = 'oder';

$lang['custom_palette']          = 'Farben anpassen';
$lang['custom_banner']           = 'Banner';
$lang['custom_banner_text']		 = 'Banner-Text';
$lang['custom_button']           = 'Button';
$lang['custom_button_text']		 = 'Button-Text';

?>