<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * cookie_consent
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2015-2019
 * @license		http://opensource.org/licenses/MIT
 * @package		Flatboard
 * @version		2.0
 * @update		2019-02-15
 */	
 
/**
 * On pré-installe les paramètres par défauts.
**/
function cookie_consent_install()
{
	global $lang; 	
	$plugin = 'cookie_consent';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state'] = false;
    $data['palette']  	   = '';
    $data['theme']  	   = 'edgeless';  
    $data['position']  	   = 'bottom-right';   
    $data['message']   	   = $lang['default_cookie_msg'];
    $data['dismiss']  	   = 'Ok accepter';
    $data['link']  	  	   = 'En savoir plus';  
    $data['href']  	       = 'https://www.google.com/intl/fr/policies/technologies/cookies/';
    $data['custom_palette'] = false;  
    $data['custom_banner'] = '';  
    $data['custom_banner_text'] = ''; 
    $data['custom_button'] = '';
    $data['custom_button_text'] = '';      
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function cookie_consent_config()
{    
	   global $lang, $token; 
       $plugin = 'cookie_consent';
       $out ='<style>
.theme-preview-container {
    display: inline-block;	
    background: black;
    height: 30px;
    width: 45px;
    padding: 5px;
}       
.theme-preview-button {
    background: white;
    height: 10px;
    width: 15px;
    margin-top: 10px;
    margin-left: 20px;
}
.choose-colours input[type="checkbox"],.choose-colours input[type="radio"] {
    box-sizing: border-box;
    padding: 0;
}
.choose-colours .input-hidden {
    position: absolute;
    left: -9999px;
}
.choose-colours input[type=radio]:checked+label{border: 2px solid #1f323c;}
.choose-colours input[type=radio]+label{padding:3px;border:1px solid transparent}
.choose-colours input[type=radio]+label>img{width:45px;height:auto;margin:0;display:block}@media (max-width:991px){.choose-colours input[type=radio]+label>img{width:40px}}.choose-colours input[type=radio]:hover+label{border-color:rgba(31,50,60,.5);cursor:pointer}
.choose-colours input[type=radio]+label,.choose-colours input[type=radio]+label>img {
    transition: all .2s ease-in-out
}
</style>';
     
       if(!empty($_POST) && CSRF::check($token) )
       {
               $data[$plugin.'state'] = Util::isPOST('state') ? $_POST['state'] : '';
               $data['palette'] = HTMLForm::clean($_POST['palette']);
               $data['theme'] = HTMLForm::clean($_POST['theme']);
               $data['position'] = HTMLForm::clean($_POST['position']);
               $data['message'] = HTMLForm::clean($_POST['message']);
               $data['dismiss'] = HTMLForm::clean($_POST['dismiss']);
               $data['link'] = HTMLForm::clean($_POST['link']);
               $data['href'] = HTMLForm::clean($_POST['href']); 
               $data['custom_palette'] = isset($_POST['custom_palette'])? $_POST['custom_palette'] : '';  
               $data['custom_banner'] = HTMLForm::clean($_POST['custom_banner']);  
			   $data['custom_banner_text'] = HTMLForm::clean($_POST['custom_banner_text']); 
			   $data['custom_button'] = HTMLForm::clean($_POST['custom_button']);
			   $data['custom_button_text'] = HTMLForm::clean($_POST['custom_button_text']);                               
               flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
       }
        else
       {
               if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
               $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
               HTMLForm::checkBox('state', $data[$plugin.'state']).
               '<h6>' .$lang['palette']. '</h6>
               <div id="choose-colours" class="choose-colours">

					<input name="palette" id="theme1-colour" class="input-hidden" value="theme1" type="radio"' .($data['palette']=='theme1' ? ' checked="checked"' : ''). '><label for="theme1-colour"><div class="theme-preview-container" style="background:#000;"><div class="theme-preview-button" style="background:#f1d600;"></div></div></label>
					
					<input name="palette" id="theme2-colour" class="input-hidden" value="theme2" type="radio"' .($data['palette']=='theme2' ? ' checked="checked"' : ''). '><label for="theme2-colour"><div class="theme-preview-container" style="background:#eaf7f7;"><div class="theme-preview-button" style="background:#56cbdb;"></div></div></label>
					
					<input name="palette" id="theme3-colour" class="input-hidden" value="theme3" type="radio"' .($data['palette']=='theme3' ? ' checked="checked"' : ''). '><label for="theme3-colour"><div class="theme-preview-container" style="background:#252e39;"><div class="theme-preview-button" style="background:#14a7d0;"></div></div></label>
					
					<input name="palette" id="theme4-colour" class="input-hidden" value="theme4" type="radio"' .($data['palette']=='theme4' ? ' checked="checked"' : ''). '><label for="theme4-colour"><div class="theme-preview-container" style="background:#000;"><div class="theme-preview-button" style="background:#0f0;"></div></div></label>
					
					<input name="palette" id="theme5-colour" class="input-hidden" value="theme5" type="radio"' .($data['palette']=='theme5' ? ' checked="checked"' : ''). '><label for="theme5-colour"><div class="theme-preview-container" style="background:#3937a3;"><div class="theme-preview-button" style="background:#e62576;"></div></div></label>
					
					<input name="palette" id="theme6-colour" class="input-hidden" value="theme6" type="radio"' .($data['palette']=='theme6' ? ' checked="checked"' : ''). '><label for="theme6-colour"><div class="theme-preview-container" style="background:#64386b;"><div class="theme-preview-button" style="background:#f8a8ff;"></div></div></label>
					
					<input name="palette" id="theme7-colour" class="input-hidden" value="theme7" type="radio"' .($data['palette']=='theme7' ? ' checked="checked"' : ''). '><label for="theme7-colour"><div class="theme-preview-container" style="background:#237afc;"><div class="theme-preview-button" style="background:#fff;"></div></div></label>
					
					<input name="palette" id="theme8-colour" class="input-hidden" value="theme8" type="radio"' .($data['palette']=='theme8' ? ' checked="checked"' : ''). '><label for="theme8-colour"><div class="theme-preview-container" style="background:#aa0000;"><div class="theme-preview-button" style="background:#ff0000;"></div></div></label>
					
					<input name="palette" id="theme9-colour" class="input-hidden" value="theme9" type="radio"' .($data['palette']=='theme9' ? ' checked="checked"' : ''). '><label for="theme9-colour"><div class="theme-preview-container" style="background:#383b75;"><div class="theme-preview-button" style="background:#f1d600;"></div></div></label>
					
					<input name="palette" id="theme10-colour" class="input-hidden" value="theme10" type="radio"' .($data['palette']=='theme10' ? ' checked="checked"' : ''). '><label for="theme10-colour"><div class="theme-preview-container" style="background:#1d8a8a;"><div class="theme-preview-button" style="background:#62ffaa;"></div></div></label>
					
					<input name="palette" id="theme11-colour" class="input-hidden" value="theme11" type="radio"' .($data['palette']=='theme11' ? ' checked="checked"' : ''). '><label for="theme11-colour"><div class="theme-preview-container" style="background:#edeff5;"><div class="theme-preview-button" style="background:#4b81e8;"></div></div></label>
					
					<input name="palette" id="theme12-colour" class="input-hidden" value="theme12" type="radio"' .($data['palette']=='theme12' ? ' checked="checked"' : ''). '><label for="theme12-colour"><div class="theme-preview-container" style="background:#343c66;"><div class="theme-preview-button" style="background:#f71559;"></div></div></label>
					
					<input name="palette" id="theme13-colour" class="input-hidden" value="theme13" type="radio"' .($data['palette']=='theme13' ? ' checked="checked"' : ''). '><label for="theme13-colour"><div class="theme-preview-container" style="background:#216942;"><div class="theme-preview-button" style="background:#afed71;"></div></div></label>
					
					<input name="palette" id="theme14-colour" class="input-hidden" value="theme14" type="radio"' .($data['palette']=='theme14' ? ' checked="checked"' : ''). '><label for="theme14-colour"><div class="theme-preview-container" style="background:#3c404d;"><div class="theme-preview-button" style="background:#8bed4f;"></div></div></label>
					
					<input name="palette" id="theme15-colour" class="input-hidden" value="theme15" type="radio"' .($data['palette']=='theme15' ? ' checked="checked"' : ''). '><label for="theme15-colour"><div class="theme-preview-container" style="background:#eb6c44;"><div class="theme-preview-button" style="background:#f5d948;"></div></div></label>
					
					<input name="palette" id="theme16-colour" class="input-hidden" value="theme16" type="radio"' .($data['palette']=='theme16' ? ' checked="checked"' : ''). '><label for="theme16-colour"><div class="theme-preview-container" style="background:#efefef;"><div class="theme-preview-button" style="background:#8ec760;"></div></div></label>
					
			   </div><!-- /.choose-colours -->
			   
			   	<div class="divider text-center text-uppercase">' .$lang['or']. '</div>
			   
			 			   
				<button class="btn btn-primary mb-3" type="button" data-toggle="collapse" data-target="#customOption" aria-expanded="false" aria-controls="collapseExample">
				  <i class="fa fa-magic" aria-hidden="true"></i> ' .$lang['custom_palette']. '
				</button>

				<div class="collapse" id="customOption">
					<div class="row">
					    <div class="col-12">'.
					    	HTMLForm::checkBox('custom_palette', $data['custom_palette']).
					    '</div>
					</div>		
					<div class="row">
					    <div class="col">'.
					    	HTMLForm::text('custom_banner', isset($data)? $data['custom_banner'] : '', 'text', 'color').
					    '</div>
					    <div class="col">'.
					    	HTMLForm::text('custom_button', isset($data)? $data['custom_button'] : '', 'text', 'color'). 
					    '</div>
					    <div class="col">'.
					    	HTMLForm::text('custom_banner_text', isset($data)? $data['custom_banner_text'] : '', 'text', 'color').
					    '</div>
					    <div class="col">'.
					    	HTMLForm::text('custom_button_text', isset($data)? $data['custom_button_text'] : '', 'text', 'color'). 
					    '</div>
					</div>					
				</div>
				<div class="row">
					<div class="col-6">'.
						HTMLForm::select('theme', array('block'=>$lang['block'], 'classic'=>$lang['classic'], 'edgeless'=>$lang['edgeless']), $data['theme']). '
					</div>
					<div class="col-6">'.
						HTMLForm::select('position', array('bottom'=>$lang['banner_bottom'], 'top'=>$lang['banner_top'], 'bottom-left'=>$lang['floating_left'], 'bottom-right'=>$lang['floating_right']), $data['position']). '
					</div>
				</div>'.
               HTMLForm::textarea('message', $data['message'], '', '', 4).
               HTMLForm::text('dismiss', isset($data)? $data['dismiss'] : '', 'text'). 
               HTMLForm::text('link', isset($data)? $data['link'] : '', 'text'). 
               HTMLForm::text('href', isset($data)? $data['href'] : '', 'url'). 
               HTMLForm::simple_submit());
       }
       return $out;
} 
/**
 * On charge la minification avant
**/
function cookie_consent_head()
{
  $plugin = 'cookie_consent';
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  $config = flatDB::readEntry('config', 'config');
  $out='';
  $assets = HTML_PLUGIN_DIR. $plugin. DS. 'assets' . DS;
  
  if ($data[$plugin.'state'])
  {	
	$out .='	<link rel="stylesheet" type="text/css" href="' .$assets. 'cookieconsent.min.css?ver=3.0.3" />'.PHP_EOL;			    
  } 
  return $out;   
}

/** 
 * Ajoute du Javascript en pied de page du thème (footer.html)
 */
function cookie_consent_footerJS() { 
	global $lang;
  	$plugin = 'cookie_consent';
  	# Lecture des données
  	$data = flatDB::readEntry('plugin', $plugin);
  	$out='';
  	$assets = HTML_PLUGIN_DIR. $plugin. DS. 'assets' . DS;
  	
	if ($data[$plugin.'state']) {	
		$out .='	<script src="' .$assets. 'cookieconsent.min.js?ver=3.0.3"></script>'.PHP_EOL;
		$out .='	<script>'.PHP_EOL;
		$out .='		window.addEventListener("load", function(){
		window.cookieconsent.initialise({';
		if ($data['palette']=='theme1' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#000"
		    },
		    "button": {
		      "background": "#f1d600"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme2' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#eaf7f7",
		      "text": "#5c7291"
		    },
		    "button": {
		      "background": "#56cbdb",
		      "text": "#ffffff"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme3' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#252e39"
		    },
		    "button": {
		      "background": "#14a7d0"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme4' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#000",
		      "text": "#0f0"
		    },
		    "button": {
		      "background": "#0f0"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme5' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#3937a3"
		    },
		    "button": {
		      "background": "#e62576"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme6' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#64386b",
		      "text": "#ffcdfd"
		    },
		    "button": {
		      "background": "#f8a8ff",
		      "text": "#3f0045"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme7' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#237afc"
		    },
		    "button": {
		      "background": "#fff",
		      "text": "#237afc"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme8' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#aa0000",
		      "text": "#ffdddd"
		    },
		    "button": {
		      "background": "#ff0000"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme9' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#383b75"
		    },
		    "button": {
		      "background": "#f1d600"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme10' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#1d8a8a"
		    },
		    "button": {
		      "background": "#62ffaa"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme11' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#edeff5",
		      "text": "#838391"
		    },
		    "button": {
		      "background": "#4b81e8"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme12' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#343c66",
		      "text": "#cfcfe8"
		    },
		    "button": {
		      "background": "#f71559"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme13' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#216942",
		      "text": "#b2d192"
		    },
		    "button": {
		      "background": "#afed71"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme14' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#3c404d",
		      "text": "#d6d6d6"
		    },
		    "button": {
		      "background": "#8bed4f"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme15' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#eb6c44",
		      "text": "#ffffff"
		    },
		    "button": {
		      "background": "#f5d948"
		    }
		  },'.PHP_EOL;
		}
		if ($data['palette']=='theme16' && !$data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "#efefef",
		      "text": "#404040"
		    },
		    "button": {
		      "background": "#8ec760",
		      "text": "#ffffff"
		    }
		  },'.PHP_EOL;
		}
		if ($data['custom_palette']) { 
			$out .='"palette": {
		    "popup": {
		      "background": "' .$data['custom_banner']. '",
		      "text": "' .$data['custom_banner_text']. '"
		    },
		    "button": {
		      "background": "' .$data['custom_button']. '",
		      "text": "' .$data['custom_button_text']. '"
		    }
		  },'.PHP_EOL;
		}	
		  $out .='
		  "theme": "' .$data['theme']. '",
		  "position": "' .$data['position']. '",
		  "content": {
		    "message": "' .$data['message']. '",
		    "dismiss": "' .$data['dismiss']. '",
		    "link": "' .$data['link']. '",
		    "href": "' .$data['href']. '"
		  }
		})});'.PHP_EOL;
		$out .='	</script>'.PHP_EOL;			        
	} 
	return $out; 
}