var ccName;
var form = document.getElementById('cookie-consent-configurator');

form.onchange = function () { update(); };

function update () {
    var options = getOptions(getInputs(form));
    draw(getOptions(getInputs(form)));
    setCode(getCode(options));
    updateForm(form);
}

function draw(options) {
    // fix to a stupid bug, that only affects configurator
    options.elements = {messagelink : '<span id="cookieconsent:desc" class="cc-message">{{message}} <a aria-label="learn more about cookies" tabindex="0" class="cc-link" href="{{href}}" target="_blank">{{link}}</a></span>'};
    options.onPopupOpen = function () {
        if(options.static)  pushDown(this.element.clientHeight, true);
        else pushDown(0);
    };
    options.onPopupClose = function () {
        pushDown(0, true);
    }

    function openCC() {
        window.cookieconsent.initialise(options, function (popup) {
            ccName = popup.open();
        });
    }
    if (!ccName) {
        openCC();
    }
    else {
        ccName.destroy();
        pushDown(0);
        openCC();
    }
}


// fixes navbar for this theme

function pushDown(height, transition) {
     var navbar = document.getElementsByClassName("navbar-fixed-top")[0];

    if(transition) {
         navbar.style.transition = 'all 1s';
    } else {
         navbar.style.transition = 'none';
    }
    navbar.style.marginTop = height+'px';
}

function getCode (config) {
    var json = JSON.stringify(config, null, 2);
    var code = escapeHtml('<link rel="stylesheet" type="text/css" href="'+ window.CookieOptionsWP +'/cookieconsent.min.css" />\n');
    code += escapeHtml('<scr'+'ipt')+'&nbsp;'+escapeHtml('src="'+ window.CookieOptionsWP + '/cookieconsent.min.js">' + '</scr'+'ipt>\n');
    code += escapeHtml('<scr'+'ipt>' + '\nwindow.addEventListener("load", function(){\nwindow.cookieconsent.initialise(' + json + ')});' + '\n</scr'+'ipt>');
    return code;
}

function setCode (code) {
    document.getElementById('code').innerHTML = code;
}

function getOptions(input) {
    var content = {};
    var options = {};

    var t = input.text;
    //if (t.header)  content.header = t.header;
    if (t.message) content.message = escapeHtml(t.message);
    if (t.dismiss) content.dismiss = escapeHtml(t.dismiss);
    if (t.allow)   content.allow = escapeHtml(t.allow);
    if (t.deny)    content.deny = escapeHtml(t.deny);
    if (t.link)    content.link = escapeHtml(t.link);

    var palette = getThemes()[input.theme];

    // if any colors have been replaced from the theme, use them instead.
    if(input.colour.popup) {
        palette.popup.background = input.colour.popup;
        input.colour.popupText ? palette.popup.text=input.colour.popupText : delete palette.popup.text;
    } else {
        palette.popup.text = input.colour.popupText ? input.colour.popupText : palette.popup.text;
    }
    if(input.colour.button) {
        palette.button.background =  input.colour.button;
        input.colour.buttonText ? palette.button.text=input.colour.buttonText : delete palette.button.text;
    } else {
        palette.button.text = input.colour.buttonText ? input.colour.buttonText : palette.button.text;
    }

    if (form.querySelectorAll('[name="choose-layout"]:checked').item(0).value == 'wire') {
        palette.button.border = palette.button.background;
        palette.button.background = 'transparent';
        palette.button.text = ( input.colour.buttonText && input.colour.buttonText != palette.button.background) ? input.colour.buttonText : palette.button.border;

    }

    options.palette = palette;

    //remove link if user didnt fill in field
    if(input.policy == 'policylink') {
        input.href ? content.href = input.href : options.showLink = false;
    }

    // only add if not default
    if(input.layout != 'block' && input.layout != 'wire') options.theme = input.layout;
    if(input.position != 'bottom') {
        if(input.position == 'top-push') {
            options.position = 'top';
            options.static = true;
        }
        else options.position = input.position;
    }
    if(input.compliance != 'info') options.type = input.compliance;

    //if has any content, add content
    for(var key in content) {
        if (content.hasOwnProperty(key)) {
            options.content = content;
            break;
        }
    }

    return options;
}

function getInputs (elem) {
    return {
        text: {
            allow: elem.querySelector('[name="allow-text"]').value,
            link: elem.querySelector('[name="link-text"]').value,
            message: elem.querySelector('[name="message-text"]').value,
            deny: elem.querySelector('[name="deny-text"]').value,
            dismiss: elem.querySelector('[name="dismiss-text"]').value,
        },
        colour: {
            popup: elem.querySelector('[name="background-color"]').value,
            button: elem.querySelector('[name="button-color"]').value,
            popupText: elem.querySelector('[name="background-text-color"]').value,
            buttonText: elem.querySelector('[name="button-text-color"]').value,
        },
        href: elem.querySelector('[name="link-href"]').value,
        policy: elem.querySelectorAll('[name="policy"]:checked').item(0).value,
        position: elem.querySelectorAll('[name="choose-position"]:checked').item(0).value,
        layout: elem.querySelectorAll('[name="choose-layout"]:checked').item(0).value,
        theme: elem.querySelectorAll('[name="theme-selector"]:checked').item(0).value,
        compliance: elem.querySelectorAll('[name="choose-cookie-compliance"]:checked').item(0).value
    }
}

function escapeHtml(html) {
    // let the spec decide how to escape the html
    var text = document.createTextNode(html);
    var div = document.createElement('div');
    div.appendChild(text);
    return div.innerHTML;
}

function updateForm(form) {
    document.getElementById('text-policylink-container').style.display = (form.querySelectorAll('[name="policy"]:checked').item(0).value == 'policylink' && form.querySelector('[name="link-href"]').value == '') ? 'none' : 'inline';
    document.getElementById('text-accept-container').style.display = form.querySelectorAll('[name="choose-cookie-compliance"]:checked').item(0).value != 'opt-in' ? 'none' : 'inline';
    document.getElementById('text-deny-container').style.display = form.querySelectorAll('[name="choose-cookie-compliance"]:checked').item(0).value != 'opt-out' ? 'none' : 'inline';
    document.getElementById('advanced-text').style.display = form.querySelectorAll('[name="choose-cookie-compliance"]:checked').item(0).value == 'info' ? 'none' : 'inline';
}

// Form builer on window load
$(function() {
    // Adds color picker to fields
    for (var i = 1; i < 5; i++) {
        $('#cp'+i).colorpicker({format: 'hex'});
        var specialSection = document.getElementById('cp'+i);
        specialSection.changeColor = function() {update();};
    }

    //add themes
    var themes = getThemes();
    var container = $('#choose-colours');
    var isChecked = false;
    for (var key in themes) {
        var html = '';
        var checked = '';
        if (!isChecked) {
            checked = 'checked';
            isChecked = true;
        }
        var sel = getThemes()[key];
        html += '<input type="radio" name="theme-selector" id="' + key + '-colour" class="input-hidden" value="'+ key +'" ' + checked + ' />';
        var whiteborder = sel.popup.background == '#fff' ? 'border: 1px solid lightgray;' : '';
        html += '<label for="'+ key +'-colour"><div class="theme-preview-container" style="background:'+ sel.popup.background + ';' + whiteborder +'">';
        html += '<div class="theme-preview-button" style="background:'+ sel.button.background + ';"></div></div></label>';
        container.append(html);
    }

    // loading Clipboard
    var clipboard = new Clipboard('.copybutton');
    clipboard.on('success', function(e) {document.getElementById('copybutton').innerHTML = 'Copied';});
    clipboard.on('error', function(e) {document.getElementById('copybutton').innerHTML = 'Press Ctrl+C to copy';});
    document.getElementById('copybutton').onfocusout=function(){document.getElementById('copybutton').innerHTML = 'Copy code';};

    // update the app on form load
    update();
});

