<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']         = 'Who is online?';
$lang[$plugin.'version']      = '2.2';
$lang[$plugin.'update']       = '2019-04-01';
$lang[$plugin.'author']       = 'Frédéric K.';
$lang[$plugin.'author_site']  = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']  = 'stradfred@gmail.com';
$lang[$plugin.'description']  = 'Displays the number of connected simultaneously on your forum';
/************* Config Plugin ***************/ 
$lang['online']       	   = 'Online: ';
$lang[$plugin.'_display']  = 'Display';
$lang['text']              = 'Text';
$lang['icon']              = 'Icon';
$lang['color']      	   = 'Color view';
$lang['dark']       	   = 'Black';
$lang['red']          	   = 'Red';
$lang['white']        	   = 'White';
$lang['green']        	   = 'Green';
$lang['blue']         	   = 'Blue';
$lang['cyan']      	   	   = 'Cyan';
$lang['grey']      	 	   = 'Grey';
$lang['yellow']      	   = 'Yellow';
$lang['staff_online'] 	   = 'Staff online';
?>