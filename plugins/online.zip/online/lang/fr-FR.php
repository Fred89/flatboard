<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']         = 'Qui est en ligne ?';
$lang[$plugin.'version']      = '2.2';
$lang[$plugin.'update']       = '2019-04-01';;
$lang[$plugin.'author']       = 'Frédéric K.';
$lang[$plugin.'author_site']  = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']  = 'stradfred@gmail.com';
$lang[$plugin.'description']  = 'Affiche le nombre de connecté en simultané sur votre forum';
/************* Config Plugin ***************/                     
$lang['online']            = 'En ligne: ';
$lang[$plugin.'_display']  = 'Affichage';
$lang['text']              = 'Texte';
$lang['icon']              = 'Icône';
$lang['color']             = 'Couleur d’affichage';
$lang['dark']              = 'Noir';
$lang['red']               = 'Rouge';
$lang['white']             = 'Blanc';
$lang['green']             = 'Vert';
$lang['blue']              = 'Bleu';
$lang['cyan']      	   	   = 'Turquoise';
$lang['grey']      	 	   = 'Gris';
$lang['yellow']            = 'Jaune';
$lang['staff_online']	   = 'Équipe en ligne';
?>