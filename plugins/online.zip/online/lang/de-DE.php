<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']         = 'Who is online?';
$lang[$plugin.'version']      = '2.2';
$lang[$plugin.'update']       = '2019-04-01';
$lang[$plugin.'author']       = 'Frédéric K.';
$lang[$plugin.'author_site']  = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']  = 'stradfred@gmail.com';
$lang[$plugin.'description']  = 'Zeigt die Anzahl der gleichzeitig zugreifenden Personen in Ihrem Forum an.';
/************* Config Plugin ***************/
$lang['online']            = 'Online: ';
$lang[$plugin.'_display']  = 'Anzeige';
$lang['text']              = 'Text';
$lang['icon']              = 'Icon';
$lang['color']             = 'Farbansicht';
$lang['dark']              = 'Schwarz';
$lang['red']               = 'Rot';
$lang['white']             = 'Weiss';
$lang['green']             = 'Gr&uuml:n';
$lang['blue']              = 'Blau';
$lang['cyan']              = 'Cyan';
$lang['grey']              = 'Grau';
$lang['yellow']            = 'Gelb';
$lang['staff_online']      = 'Mitarbeiter online';
?>