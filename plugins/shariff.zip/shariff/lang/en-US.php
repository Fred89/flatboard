<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Shariff';
$lang[$plugin.'version']         = '3.1.1';
$lang[$plugin.'update']          = '2019-02-17';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Shariff enables website users to share their favorite content without compromising their privacy.';

$lang['backend']   			= 'Backend'; 
$lang['data-theme']   		= 'Color schemes'; 
$lang['standard']			= 'Standard';
$lang['grey']  				= 'Grey';
$lang['white']				= 'White';
$lang['data-backend']   	= 'Display share counts';
$lang[$plugin.'domaine']	= 'Domain name (ex: www.domain.com)';
$lang['data-orientation']   = 'Buttons orientation';
$lang['vertical']   		= 'Vertical';
$lang['horizontal']   		= 'Horizontal';
$lang['data-services']   	= 'Buttons to display';  
$lang['data-services_desc'] = 'Available service names: <code>&quot;twitter&quot;, &quot;facebook&quot;, &quot;linkedin&quot;, &quot;pinterest&quot;, &quot;xing&quot;, &quot;whatsapp&quot;, &quot;mail&quot;, &quot;info&quot;, &quot;addthis&quot;, &quot;tumblr&quot;, &quot;flattr&quot;, &quot;diaspora&quot;, &quot;reddit&quot;, &quot;stumbleupon&quot;, &quot;threema&quot;, &quot;weibo&quot;, &quot;tencent-weibo&quot;, &quot;qzone&quot;, &quot;print&quot;, &quot;telegram&quot;, &quot;vk&quot;, &quot;flipboard&quot;, &quot;pocket&quot;</code>';
?>