<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Shariff';
$lang[$plugin.'version']         = '3.1.1';
$lang[$plugin.'update']          = '2019-02-17';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Shariff erm&ouml;glicht es Website-Benutzern, ihre Lieblingsinhalte zu teilen, ohne ihre Privatsph&auml;re zu gef&auml;hrden..';

$lang['backend']                 = 'Backend';
$lang['data-theme']              = 'Farbschemata';
$lang['standard']                = 'Standard';
$lang['grey']                    = 'Grau';
$lang['white']                   = 'Weiss';
$lang['data-backend']            = 'Share-Z&auml;hler anzeigen';
$lang[$plugin.'domaine']		 = 'Domain name (ex: www.domain.com)';
$lang['data-orientation']   	 = 'Orientierung der Buttons';
$lang['vertical']                = 'Vertikal';
$lang['horizontal']              = 'Horizontal';
$lang['data-services']           = 'Anzuzeigende Buttons';
$lang['data-services_desc'] 	 = 'Verf&uuml;gbare Namen der Services: <code>&quot;twitter&quot;, &quot;facebook&quot;, &quot;linkedin&quot;, &quot;pinterest&quot;, &quot;xing&quot;, &quot;whatsapp&quot;, &quot;mail&quot;, &quot;info&quot;, &quot;addthis&quot;, &quot;tumblr&quot;, &quot;flattr&quot;, &quot;diaspora&quot;, &quot;reddit&quot;, &quot;stumbleupon&quot;, &quot;threema&quot;, &quot;weibo&quot;, &quot;tencent-weibo&quot;, &quot;qzone&quot;, &quot;print&quot;, &quot;telegram&quot;, &quot;vk&quot;, &quot;flipboard&quot;, &quot;pocket&quot;</code>';
?>