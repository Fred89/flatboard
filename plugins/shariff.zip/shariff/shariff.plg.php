<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * shariff
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2015-2019
 * @license		http://opensource.org/licenses/MIT
 * @package		FlatBoard
 * @version		3.1.1
 * @update		2019-02-17
 */	
	 
/**
 * On pré-installe les paramètres par défauts.
**/
function shariff_install()
{
	$plugin = 'shariff';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state']    = false;
    $data[$plugin.'domaine']  = getenv('HTTP_HOST'); 
    $data['data-theme']   	  = 'standard';
    $data['data-backend']     = false;
    $data['data-orientation'] = 'horizontal';
    $data['data-services']    = "&quot;twitter&quot;, &quot;facebook&quot;, &quot;linkedin&quot;, &quot;pinterest&quot;, &quot;info&quot;";       
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function shariff_config()
{    
	   global $lang, $token; 
       $plugin = 'shariff';
       $out ='';
       $Backend = HTML_PLUGIN_DIR. $plugin .DS. 'backend' .DS. '?url=' .urlencode(Util::baseURL());
        
       if(!empty($_POST) && CSRF::check($token) )
       {
               $data[$plugin.'state'] 	 = Util::isPOST('state') ? $_POST['state'] : '';
               $data['data-theme'] 		 = HTMLForm::clean($_POST['data-theme']);
               $data['data-backend'] 	 = isset($_POST['data-backend'])? $_POST['data-backend'] : '';
               $data[$plugin.'domaine']  = HTMLForm::clean($_POST[$plugin.'domaine']);
               $data['data-orientation'] = HTMLForm::clean($_POST['data-orientation']); 
               $data['data-services'] 	 = HTMLForm::clean($_POST['data-services']);             
               flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
       }
        else
       {
               if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
               $out .= ($data['data-backend'] ? '<a class="btn btn-primary" href="' .$Backend. '"><i class="fa fa-star" aria-hidden="true"></i> ' .$lang['backend']. '</a>' : '').
               HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
               HTMLForm::checkBox('state', isset($data)? $data[$plugin.'state'] : '').
               HTMLForm::checkBox('data-backend', isset($data)? $data['data-backend'] : '').
               HTMLForm::text($plugin.'domaine', isset($data)? $data[$plugin.'domaine'] : '', 'text','col-§'). '
			   <div class="form-row">
				    <div class="col-3">
				        ' .HTMLForm::select('data-theme', array('standard'=> $lang['standard'], 'grey'=> $lang['grey'], 'white'=> $lang['white']), $data['data-theme']). '
				    </div>
				    <div class="col-3">
				        ' .HTMLForm::select('data-orientation', array('vertical'=> $lang['vertical'], 'horizontal'=> $lang['horizontal']), $data['data-orientation']). '			        
				    </div>
			   </div>' . 
               HTMLForm::textarea('data-services', Parser::htmlDecode($data['data-services']), '', Parser::htmlDecode('data-services_desc'), 4).
               HTMLForm::simple_submit('submit', '', 'fa fa-check'));
       }
       return $out;
} 
/**
 * On charge la minification avant
**/
function shariff_head()
{
  $plugin = 'shariff';
  # Lecture des données
  $PluginActivate = FlatDB::readEntry('plugin',$plugin)[$plugin.'state'];
  if ($PluginActivate)
	return '  <link href="' .HTML_PLUGIN_DIR. $plugin. DS. 'build' .DS. 'shariff.complete.css" rel="stylesheet">'.PHP_EOL;
	     
}
/**
 * On charge les boutons de partage
**/
function shariff_bottomTopic($topic)
{
  $plugin = 'shariff';
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  $config = flatDB::readEntry('config', 'config');
  $l = substr($config['lang'], 0, -3);
  
  if ($data[$plugin.'state'])
  {
	$topicEntry = flatDB::readEntry('topic', $topic);  
	$Url = HTML_BASEPATH . DS . 'view.php' . DS . 'topic' . DS . $topic;
	$Description = Parser::summary($topicEntry['content'],20);
	$Title = urlencode($topicEntry['title']);
	$Backend = HTML_PLUGIN_DIR. $plugin .DS. 'backend' .DS. '?url=' .urlencode(Util::baseURL());
	
   	return '<div class="shariff"' .($data['data-backend'] ? ' data-backend-url="' .$Backend. '"' : ''). ' data-url="' .$Url. '" data-theme="' .$data['data-theme']. '" data-orientation="' .$data['data-orientation']. '" data-lang="' .$l. '" data-services="[' .$data['data-services']. ']"></div>'.PHP_EOL;	    
  }    
}

/** 
 * Ajoute du Javascript en pied de page du thème
 */
 function shariff_footerJS() { 
  	$plugin = 'shariff';
  	# Lecture des données
  	$PluginActivate = FlatDB::readEntry('plugin',$plugin)[$plugin.'state'];
  	if ($PluginActivate)
		return '  <script src="' .HTML_PLUGIN_DIR. $plugin. DS. 'build' .DS. 'shariff.complete.js"></script>'.PHP_EOL;  
}