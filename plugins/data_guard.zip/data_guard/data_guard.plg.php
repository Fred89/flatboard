<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * data_guard
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2020
 * @license		http://opensource.org/licenses/MIT
 * @package		FlatBoard
 * @version		1.0
 * @update		2020-01-04
 */	
 
/**
 * On pré-installe les paramètres par défauts.
**/
function data_guard_install()
{
	$plugin = 'data_guard';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;
	
	$data[$plugin.'state']	= false;  
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function data_guard_config()
{    
	global $lang, $token; 
	$plugin = 'data_guard';
	$out ='';
	
	if(!empty($_POST) && CSRF::check($token) )
	{
	   $data[$plugin.'state'] = Util::isPOST('state') ? $_POST['state'] : '';           
	   flatDB::saveEntry('plugin', $plugin, $data);
	   $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
	}
	else
	{
	   if (flatDB::isValidEntry('plugin', $plugin))
	   $data = flatDB::readEntry('plugin', $plugin);
	   $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
	   HTMLForm::checkBox('state', isset($data)? $data[$plugin.'state'] : '').        
	   HTMLForm::simple_submit());
	}
	return $out;
} 
/**
 * On charge la minification avant
**/
function data_guard_footerJS()
{
  global $cur;
  $plugin = 'data_guard';
  # Lecture du statut du plugin
  $activate = flatDB::readEntry('plugin', $plugin)[$plugin.'state'];
    
  if ($activate)
  {	 
    # Load jQuery if it is not loaded yet
    $out ='<script>window.jQuery || document.write(\'<script src="//ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"><\/script>\')</script>'.PHP_EOL;
    # Disable cut copy paste
    # Disable mouse right click
    $out .='<script type="text/javascript">
                $(document).ready(function () {
                    $("body").bind("cut copy paste", function (e) {
                        e.preventDefault();
                    });
                    $("body").on("contextmenu",function(e){
                        return false;
                    });
                });
          </script>'.PHP_EOL;	   
	return $out;	    
  }    
}