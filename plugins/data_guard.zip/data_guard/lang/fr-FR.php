<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Protection des donées';
$lang[$plugin.'version']         = '1.0';
$lang[$plugin.'update']          = '2020-01-04';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue en ***************/
$lang[$plugin.'description']     = 'Ce plugin protège votre site contre la copie de contenu.';
?>