<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Signatur';
$lang[$plugin.'version']         = '2.0';
$lang[$plugin.'update']          = '2019-02-15';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Hinzuf&uuml;gen der Forum Signatur f&uuml;r einen bestimmten Benutzer.';
$lang[$plugin.'help']            = 'Kopieren und Hinzuf&uuml;gen des Benutzer-Trips in dieses Feld, HTML Code in der Signatur ist zul&auml;ssig.';

$lang['sign']                    = 'Signatur';
$lang['preview']                 = 'Vorschau';
$lang['sign_empty']              = 'Es gibt keine Signatur';
$lang['user_sign']               = 'Benutzer Signatur';
$lang['user']                    = 'Benutzer';
$lang['manage_sign']             = 'Signaturen verwalten';
$lang['display']                 = 'Siganturen auf der Webseite anzeigen lassen';
$lang['afterTopic']              = 'Hinter dem Thema';
$lang['afterReply']              = 'Hinter der Antwort';
?>