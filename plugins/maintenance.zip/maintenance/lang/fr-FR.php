<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Mode de Maintenance';
$lang[$plugin.'version']         = '1.3';
$lang[$plugin.'update']          = '2020-04-26';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Configurer votre site sur le mode de maintenance, vous pouvez accéder à la zone d’administration.'; 
$lang[$plugin.'message']     	 = 'Message';
$lang[$plugin.'message_desc']    = 'Le code HTML est autorisé.';
$lang[$plugin.'mme']     	 	 = 'Mode maintenance activé'; 
$lang[$plugin.'messageAlert']    = 'Attention de garder votre session administrateur active ! Sinon supprimer manuellement le fichier : <pre>data/plugin/maintenance.dat.php</pre>'; 
?>