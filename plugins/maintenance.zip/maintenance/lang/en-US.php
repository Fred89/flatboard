<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Maintenance mode';
$lang[$plugin.'version']         = '1.3';
$lang[$plugin.'update']          = '2020-04-26';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Set your site on maintenance mode, you can access to admin area.'; 
$lang[$plugin.'message']     	 = 'Message';
$lang[$plugin.'message_desc']    = 'HTML code is allowed.';
$lang[$plugin.'mme']     	 	 = 'Maintenance mode enabled';
$lang[$plugin.'messageAlert']    = 'Warning to keep your session active administrator! Otherwise manually delete the file: <pre>data/plugin/maintenance.dat.php</pre>'; 
?>