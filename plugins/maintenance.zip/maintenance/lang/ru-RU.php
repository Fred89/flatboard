<?php	/* Translation: https://r-e-d.red (Last update 2019.04.01)*/
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Maintenance mode';
$lang[$plugin.'version']         = '1.3';
$lang[$plugin.'update']          = '2020-04-26';
$lang[$plugin.'author']          = 'Frédéric K.';
$lang[$plugin.'author_site']     = 'http://flatboard.free.fr';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue ru ***************/
$lang[$plugin.'description']     = 'Переведите свой сайт в режим обслуживания, вы по-прежнему можете получить доступ к административной области.'; 
$lang[$plugin.'message']     	 = 'Сообщение';
$lang[$plugin.'mme']     	 	 = 'Режим обслуживания включен';
$lang[$plugin.'messageAlert']    = 'Предупреждение: важно, чтобы ваш сеанс оставался активным активным (не разлогинивайтесь)! В противном случае вручную удалите файл: <pre>data/plugin/maintenance.dat.php</pre>'; 
?>