<?php defined('FLATBOARD') or die('Flatboard Community.');
/**
 * maintenance
 *
 * @author 		Frédéric K.
 * @copyright	(c) 2015-2020
 * @license		http://opensource.org/licenses/MIT
 * @package		FlatBoard
 * @version		1.3
 * @update		2020-04-26
 */	
 
/**
 * On pré-installe les paramètres par défauts.
**/
function maintenance_install()
{
	global $config, $lang;
	$plugin = 'maintenance';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;
	$msg  = '<!DOCTYPE html>'.PHP_EOL;
	$msg .= '<html lang="' .$config['lang']. '">'.PHP_EOL;
	$msg .= '<head>'.PHP_EOL;
	$msg .= '<meta charset="UTF-8">'.PHP_EOL;
	$msg .= '<title>Site Maintenance</title>'.PHP_EOL;
	$msg .= '<style>'.PHP_EOL;
	$msg .= 'body { text-align: center; padding: 150px; }'.PHP_EOL;
	$msg .= 'h1 { font-size: 50px; }'.PHP_EOL;
	$msg .= 'body { font: 20px Helvetica, sans-serif; color: #333; }'.PHP_EOL;
	$msg .= 'article { display: block; text-align: left; width: 650px; margin: 0 auto; }'.PHP_EOL;
	$msg .= 'a { color: #2196F3; text-decoration: none; }'.PHP_EOL;
	$msg .= 'a:hover { color: #5352ed; text-decoration: none; }'.PHP_EOL;
	$msg .= 'small { color: #a4b0be; font-style: italic; font-size: small}'.PHP_EOL;
	$msg .= '</style>'.PHP_EOL;
	$msg .= '</head>'.PHP_EOL;
	$msg .= '<body>'.PHP_EOL;	
	$msg .= '<article>'.PHP_EOL;
	$msg .= '<h1>We’ll be back soon!</h1>'.PHP_EOL;
	$msg .= '<div>'.PHP_EOL;
	$msg .= '<p>Sorry for the inconvenience but we’re performing some maintenance at the moment. If you need to you can always <a href="mailto:' .$config['mail']. '">contact us</a>, otherwise we’ll be back online shortly!</p>'.PHP_EOL;
	$msg .= '<p>'.PHP_EOL;
	$msg .= '— ' .$config['title']. ' Team.<br />'.PHP_EOL;
	$msg .= '<small>Maintenance Mode v.'.$lang[$plugin.'version'].'</small>'.PHP_EOL;
	$msg .= '</p>'.PHP_EOL;
	$msg .= '</div>'.PHP_EOL;
	$msg .= '</article>'.PHP_EOL;
	$msg .= '</body>'.PHP_EOL;
	$msg .= '</html>';

    $data[$plugin.'state']   = false;
    $data[$plugin.'message'] = base64_encode($msg);   
	flatDB::saveEntry('plugin', $plugin, $data);
}

/**
 * Admin
**/
function maintenance_config()
{    
	   global $lang, $token; 
       $plugin = 'maintenance';
       $out ='';
     
       if(!empty($_POST) && CSRF::check($token) )
       {
               $data[$plugin.'state']= Util::isPOST('state') ? $_POST['state'] : '';
               $data[$plugin.'message'] = base64_encode($_POST[$plugin.'message']);            
               flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
       }
        else
       {
               if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
               $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin,
               HTMLForm::checkBox('state', $data[$plugin.'state']). 
               HTMLForm::textarea($plugin.'message', base64_decode($data[$plugin.'message']), '', '', 8).        
               HTMLForm::simple_submit());
       }
       return $out;
} 

/**
 * On charge le mode de maintenance
**/
function maintenance_init()
{
  $plugin = 'maintenance';
  # Lecture des données
  $data = flatDB::readEntry('plugin', $plugin);
  if ($data[$plugin.'state'] && !User::isAdmin())		
	# Add maintenance message
	exit(base64_decode($data[$plugin.'message']));   
}

/**
 * On informe l'administrateur que le mode 
 * de maintenance est activé.
**/
function maintenance_adminBeforeMain()
{
  global $lang;	
  $plugin = 'maintenance';
  # Lecture des données
  $PluginActivate = FlatDB::readEntry('plugin',$plugin)[$plugin.'state'];

  if ($PluginActivate)		
		# Add maintenance message
		return '<div class="alert alert-danger" role="alert"><h4 class="alert-heading">' .$lang[$plugin.'mme']. '</h4>' .$lang[$plugin.'messageAlert']. '</div>';   
}